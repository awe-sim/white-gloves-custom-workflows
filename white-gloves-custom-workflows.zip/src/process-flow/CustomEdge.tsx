import { Filter2, Filter3, Filter4, Filter5, Filter6, Filter7, Filter8, Filter9, Filter9Plus, Lock, MailOutline } from '@mui/icons-material';
import { ListItem, ListItemIcon, ListItemText } from '@mui/material';
import classNames from 'classnames';
import { useEffect, useMemo } from 'react';
import { BaseEdge, EdgeLabelRenderer, EdgeProps, MarkerType, getBezierPath, useReactFlow, useViewport } from 'reactflow';
import { useSetRecoilState } from 'recoil';
import { selectedEdgeLabelCoordsState } from './states';
import { Action, State } from './types';
import { prevent } from './helpers';

export const CustomEdge: React.FC<EdgeProps<Action>> = ({ id, sourceX, sourceY, targetX, targetY, selected, label, data, ...props }) => {
  //
  const isEmailAction = data?.isEmailAction ?? false;

  const { flowToScreenPosition } = useReactFlow<State, Action>();
  const viewport = useViewport();

  const setEdgeLabelCoords = useSetRecoilState(selectedEdgeLabelCoordsState);
  const [path, labelX, labelY] = useMemo(() => getBezierPath({ sourceX, sourceY, targetX, targetY }), [sourceX, sourceY, targetX, targetY]);

  const edgeCss = useMemo<React.CSSProperties>(
    () => ({
      animation: selected ? 'dashdraw 0.5s linear infinite' : 'none',
      markerEnd: selected ? 'url(#arrow-dark-grey)' : 'url(#arrow-light-grey)',
      stroke: selected ? '#404040' : '#d0d0d0',
      strokeDasharray: selected ? 5 : 0,
      strokeWidth: selected ? '3px' : '2px',
    }),
    [selected],
  );

  useEffect(() => {
    if (selected) {
      const { x, y } = flowToScreenPosition({ x: labelX, y: labelY });
      setEdgeLabelCoords({ x, y });
    }
  }, [flowToScreenPosition, labelX, labelY, selected, setEdgeLabelCoords, viewport]);

  const hasConstraints = useMemo(() => {
    return data?.subActions.some(action => {
      if (action.constraintsConnectionsIn.length > 0) return true;
      if (action.constraintsConnectionsNotIn.length > 0) return true;
      if (action.constraintsDirectionsIn.length > 0) return true;
      if (action.constraintsDirectionsNotIn.length > 0) return true;
      if (action.constraintsOriginsIn.length > 0) return true;
      if (action.constraintsOriginsNotIn.length > 0) return true;
      if (action.constraintsStatesIn.length > 0) return true;
      if (action.constraintsStatesNotIn.length > 0) return true;
      return false;
    });
  }, [data?.subActions]);

  return (
    <>
      <BaseEdge {...props} id={id} path={path} markerEnd={MarkerType.Arrow} style={edgeCss} />
      <EdgeLabelRenderer>
        <div onDoubleClick={prevent} className={classNames('edge-label', selected && 'selected')} style={{ transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)` }}>
          <ListItem dense disablePadding>
            {isEmailAction && (
              <ListItemIcon>
                <MailOutline color="error" />
              </ListItemIcon>
            )}
            {hasConstraints && (
              <ListItemIcon>
                <Lock />
              </ListItemIcon>
            )}
            <ListItemText>{label}</ListItemText>
            {data?.subActions.length === 2 && (<ListItemIcon><Filter2 /></ListItemIcon>)}
            {data?.subActions.length === 3 && (<ListItemIcon><Filter3 /></ListItemIcon>)}
            {data?.subActions.length === 4 && (<ListItemIcon><Filter4 /></ListItemIcon>)}
            {data?.subActions.length === 5 && (<ListItemIcon><Filter5 /></ListItemIcon>)}
            {data?.subActions.length === 6 && (<ListItemIcon><Filter6 /></ListItemIcon>)}
            {data?.subActions.length === 7 && (<ListItemIcon><Filter7 /></ListItemIcon>)}
            {data?.subActions.length === 8 && (<ListItemIcon><Filter8 /></ListItemIcon>)}
            {data?.subActions.length === 9 && (<ListItemIcon><Filter9 /></ListItemIcon>)}
            {(data?.subActions.length ?? 0) > 9 && (<ListItemIcon><Filter9Plus /></ListItemIcon>)}
          </ListItem>
        </div>
      </EdgeLabelRenderer>
    </>
  );
};
