import { Button, Stack } from '@mui/material';
import classNames from 'classnames';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Handle, NodeProps, NodeToolbar, Position } from 'reactflow';
import { useReactFlowHooks } from './hooks';
import { State, Type } from './types';
import { prevent } from './helpers';

export const CustomNode: React.FC<NodeProps<State>> = ({ id, selected, dragging, data: { label, type, isEditing } }) => {
  //
  const { updateNode } = useReactFlowHooks();
  const [newLabel, setNewLabel] = useState(label);
  const ref = useRef<HTMLInputElement>(null);

  const onContentDoubleClick = useCallback(
    (ev: React.MouseEvent<HTMLDivElement>) => {
      ev.preventDefault();
      ev.stopPropagation();
      updateNode(id, draft => {
        draft.data.isEditing = true;
      });
    },
    [id, updateNode],
  );

  const onInputChange = useCallback<React.ChangeEventHandler<HTMLInputElement>>(ev => {
    setNewLabel(ev.target.value);
  }, []);

  const onInputKeyDown = useCallback<React.KeyboardEventHandler<HTMLInputElement>>(
    ev => {
      if (ev.key === 'Enter') {
        updateNode(id, draft => {
          draft.data.label = newLabel;
          draft.data.isEditing = false;
        });
      }
    },
    [id, newLabel, updateNode],
  );

  const onInputBlur = useCallback<React.FocusEventHandler>(() => {
    updateNode(id, draft => {
      draft.data.label = newLabel;
      draft.data.isEditing = false;
    });
  }, [id, newLabel, updateNode]);

  const setType = useCallback(
    (type: Type) => {
      // TODO: Check incoming/outgoing connections to see if type can indeed be changed!
      updateNode(id, draft => {
        draft.data.type = type;
      });
    },
    [id, updateNode],
  );

  useEffect(() => {
    if (selected && !dragging && isEditing) {
      setTimeout(() => {
        ref.current?.focus();
        ref.current?.select();
      }, 0);
    }
  }, [dragging, isEditing, selected]);

  return (
    <>
      <div className={classNames('custom-node', selected && 'selected', dragging && 'dragging', type)} tabIndex={-1}>
        <div onDoubleClick={onContentDoubleClick} className="content">
          {isEditing ? <input ref={ref} autoFocus value={newLabel} onChange={onInputChange} onKeyDown={onInputKeyDown} onBlur={onInputBlur} /> : label}
        </div>
        {type !== Type.START && <Handle className="handle" type="target" position={Position.Top} />}
        {type !== Type.DONE && <Handle className="handle" type="source" position={Position.Bottom} id="a" />}
      </div>
      <NodeToolbar onDoubleClick={prevent} position={Position.Top} offset={20} className={classNames('node-toolbar', selected && 'selected', dragging && 'dragging')}>
        <Stack direction="row" spacing={1}>
          <Button className={classNames(Type.START, type === Type.START && 'selected')} variant="outlined" size="small" onClick={() => setType(Type.START)}>
            Start
          </Button>
          <Button className={classNames(Type.NORMAL, type === Type.NORMAL && 'selected')} variant="outlined" size="small" onClick={() => setType(Type.NORMAL)}>
            Normal
          </Button>
          <Button className={classNames(Type.AWAITING_REPLY, type === Type.AWAITING_REPLY && 'selected')} variant="outlined" size="small" onClick={() => setType(Type.AWAITING_REPLY)}>
            Awaiting reply
          </Button>
          <Button className={classNames(Type.ERROR, type === Type.ERROR && 'selected')} variant="outlined" size="small" onClick={() => setType(Type.ERROR)}>
            Error
          </Button>
          <Button className={classNames(Type.DONE, type === Type.DONE && 'selected')} variant="outlined" size="small" onClick={() => setType(Type.DONE)}>
            Done
          </Button>
        </Stack>
      </NodeToolbar>
    </>
  );
};
