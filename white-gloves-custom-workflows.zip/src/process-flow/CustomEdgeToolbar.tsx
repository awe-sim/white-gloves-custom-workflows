import { AccessAlarm, AttachEmail, Close, Lock, LockOpen, MailOutline } from '@mui/icons-material';
import { Button, IconButton, InputLabel, List, ListItem, MenuItem, Popover, Select, SelectChangeEvent, Stack, TextField } from '@mui/material';
import { useCallback, useMemo, useState } from 'react';
import { Edge, useEdges, XYPosition } from 'reactflow';
import { useRecoilValue } from 'recoil';
import { useReactFlowHooks } from './hooks';
import { selectedEdgeIdsState, selectedEdgeLabelCoordsState } from './states';
import { Action, ProcessConnection, ProcessDirection, ProcessOrigin, SubAction } from './types';
import { prevent } from './helpers';

type CustomEdgeToolbarProps = {
  edge: Edge<Action>;
  edgeLabelCoords: XYPosition;
};
const CustomEdgeToolbar: React.FC<CustomEdgeToolbarProps> = ({ edge, edgeLabelCoords }) => {
  const { updateEdge } = useReactFlowHooks();

  const inputChange = useCallback<React.ChangeEventHandler<HTMLInputElement>>(
    ev => {
      updateEdge(edge.id, draft => {
        draft.label = ev.target.value;
      });
    },
    [edge.id, updateEdge],
  );

  const toggleEmailAction = useCallback<React.MouseEventHandler<HTMLButtonElement>>(() => {
    updateEdge(edge.id, draft => {
      draft.data = draft.data ?? {
        isEmailAction: false,
        subActions: [],
      };
      if (draft.data.isEmailAction) {
        draft.data.isEmailAction = false;
        draft.data.subActions = draft.data.subActions.slice(0, 1);
      } else {
        draft.data.isEmailAction = true;
      }
    });
  }, [edge.id, updateEdge]);

  const addVariation = useCallback(() => {
    updateEdge(edge.id, draft => {
      draft.data = draft.data ?? {
        isEmailAction: false,
        subActions: [],
      };
      draft.data.subActions.push({
        label: `Variation ${edge.data?.subActions.length ?? 0}`,
        emailTemplate: 'email-template.html',
        hasReminder: false,
        reminderEmailTemplate: 'reminder-template.html',
        constraintsConnectionsIn: [],
        constraintsConnectionsNotIn: [],
        constraintsOriginsIn: [],
        constraintsOriginsNotIn: [],
        constraintsDirectionsIn: [],
        constraintsDirectionsNotIn: [],
        constraintsStatesIn: [],
        constraintsStatesNotIn: [],
      });
    });
  }, [updateEdge, edge.id, edge.data?.subActions.length]);

  const subAction = edge.data?.subActions[0];
  const hasConstraints = useMemo(() => {
    if (subAction?.constraintsConnectionsIn.length) return true;
    if (subAction?.constraintsConnectionsNotIn.length) return true;
    if (subAction?.constraintsOriginsIn.length) return true;
    if (subAction?.constraintsOriginsNotIn.length) return true;
    if (subAction?.constraintsDirectionsIn.length) return true;
    if (subAction?.constraintsDirectionsNotIn.length) return true;
    if (subAction?.constraintsStatesIn.length) return true;
    if (subAction?.constraintsStatesNotIn.length) return true;
    return false;
  }, [subAction?.constraintsConnectionsIn.length, subAction?.constraintsConnectionsNotIn.length, subAction?.constraintsDirectionsIn.length, subAction?.constraintsDirectionsNotIn.length, subAction?.constraintsOriginsIn.length, subAction?.constraintsOriginsNotIn.length, subAction?.constraintsStatesIn.length, subAction?.constraintsStatesNotIn.length]);
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const changeConnectionConstraints = useCallback(
    (ev: SelectChangeEvent<ProcessConnection[]>) => {
      const value = ev.target.value;
      const values = typeof value === 'string' ? value.split(',').map(it => it as ProcessConnection) : value;
      updateEdge(edge.id, draft => {
        draft.data = draft.data ?? {
          isEmailAction: false,
          subActions: [],
        };
        draft.data.subActions[0].constraintsConnectionsIn = values;
      });
    },
    [edge.id, updateEdge],
  );

  const changeDirectionConstraints = useCallback(
    (ev: SelectChangeEvent<ProcessDirection[]>) => {
      const value = ev.target.value;
      const values = typeof value === 'string' ? value.split(',').map(it => it as ProcessDirection) : value;
      updateEdge(edge.id, draft => {
        draft.data = draft.data ?? {
          isEmailAction: false,
          subActions: [],
        };
        draft.data.subActions[0].constraintsDirectionsIn = values;
      });
    },
    [edge.id, updateEdge],
  );

  const changeOriginConstraints = useCallback(
    (ev: SelectChangeEvent<ProcessOrigin[]>) => {
      const value = ev.target.value;
      const values = typeof value === 'string' ? value.split(',').map(it => it as ProcessOrigin) : value;
      updateEdge(edge.id, draft => {
        draft.data = draft.data ?? {
          isEmailAction: false,
          subActions: [],
        };
        draft.data.subActions[0].constraintsOriginsIn = values;
      });
    },
    [edge.id, updateEdge],
  );

  return (
    <div onDoubleClick={prevent} className="edge-toolbar-v2" style={{ left: edgeLabelCoords?.x, top: edgeLabelCoords?.y }}>
      <Stack direction="column" spacing={1}>
        <Stack direction="row" spacing={1}>
          <IconButton size="small" color={edge?.data?.isEmailAction ? 'error' : 'default'} onClick={toggleEmailAction}>
            <MailOutline />
          </IconButton>
          <TextField size="small" variant="standard" placeholder="Action name" value={edge.label} onChange={inputChange} />
          {edge.data && edge.data.isEmailAction && edge.data.subActions.length === 1 && <SubActionRowArea id={edge.id} index={0} subAction={edge.data.subActions[0]} />}
          {edge.data && edge.data.subActions.length === 1 && (
            <>
              <IconButton size="small" onClick={ev => setAnchorEl(ev.currentTarget)}>
                {hasConstraints ? <Lock color="error" /> : <LockOpen />}
              </IconButton>
              <Popover
                open={!!anchorEl}
                anchorEl={anchorEl}
                onClose={() => setAnchorEl(null)}
                onDoubleClick={prevent}
                anchorOrigin={{
                  vertical: 'bottom',
                  horizontal: 'left',
                }}>
                <List dense style={{ width: '400px' }}>
                  <ListItem dense>
                    <InputLabel id="connections">Connections</InputLabel>
                    <Select labelId="connections" value={subAction?.constraintsConnectionsIn ?? []} size="small" variant="standard" fullWidth multiple onChange={changeConnectionConstraints}>
                      <MenuItem value={ProcessConnection.AS2}>AS2</MenuItem>
                      <MenuItem value={ProcessConnection.SFTP}>SFTP</MenuItem>
                      <MenuItem value={ProcessConnection.HTTP}>HTTP</MenuItem>
                      <MenuItem value={ProcessConnection.VAN}>VAN</MenuItem>
                      <MenuItem value={ProcessConnection.WEBHOOK}>Web Hook</MenuItem>
                    </Select>
                  </ListItem>
                  <ListItem dense>
                    <InputLabel id="origins">Directions</InputLabel>
                    <Select labelId="origins" value={subAction?.constraintsDirectionsIn ?? []} size="small" variant="standard" fullWidth multiple onChange={changeDirectionConstraints}>
                      <MenuItem value={ProcessDirection.INBOUND}>Inbound</MenuItem>
                      <MenuItem value={ProcessDirection.OUTBOUND}>Outbound</MenuItem>
                    </Select>
                  </ListItem>
                  <ListItem dense>
                    <InputLabel id="connections">Origins</InputLabel>
                    <Select labelId="connections" value={subAction?.constraintsOriginsIn ?? []} size="small" variant="standard" fullWidth multiple onChange={changeOriginConstraints}>
                      <MenuItem value={ProcessOrigin.INTERNAL}>Internal</MenuItem>
                      <MenuItem value={ProcessOrigin.EXTERNAL}>External</MenuItem>
                    </Select>
                  </ListItem>
                </List>
              </Popover>
            </>
          )}
          <Button size="large" variant="outlined" onClick={addVariation}>
            + Variant
          </Button>
        </Stack>
        {edge.data && edge.data.subActions.length > 1 && edge.data.subActions.map((subAction, index) => <SubActionRow key={index} id={edge.id} index={index} subAction={subAction} />)}
      </Stack>
    </div>
  );
};

// ------------------------------------------------------------------------------------------------

type SubActionProps = {
  id: string;
  index: number;
  subAction: SubAction;
};
const SubActionRow: React.FC<SubActionProps> = ({ id, index, subAction }) => {
  const { updateEdge } = useReactFlowHooks();

  const inputChange = useCallback<React.ChangeEventHandler<HTMLInputElement>>(
    ev => {
      updateEdge(id, draft => {
        draft.data = draft.data ?? {
          isEmailAction: false,
          subActions: [],
        };
        draft.data.subActions[index].label = ev.target.value;
      });
    },
    [id, index, updateEdge],
  );

  const deleteSubAction = useCallback(() => {
    updateEdge(id, draft => {
      draft.data = draft.data ?? {
        isEmailAction: false,
        subActions: [],
      };
      draft.data.subActions.splice(index, 1);
    });
  }, [updateEdge, id, index]);

  const hasConstraints = useMemo(() => {
    if (subAction.constraintsConnectionsIn.length) return true;
    if (subAction.constraintsConnectionsNotIn.length) return true;
    if (subAction.constraintsOriginsIn.length) return true;
    if (subAction.constraintsOriginsNotIn.length) return true;
    if (subAction.constraintsDirectionsIn.length) return true;
    if (subAction.constraintsDirectionsNotIn.length) return true;
    if (subAction.constraintsStatesIn.length) return true;
    if (subAction.constraintsStatesNotIn.length) return true;
    return false;
  }, [subAction.constraintsConnectionsIn.length, subAction.constraintsConnectionsNotIn.length, subAction.constraintsDirectionsIn.length, subAction.constraintsDirectionsNotIn.length, subAction.constraintsOriginsIn.length, subAction.constraintsOriginsNotIn.length, subAction.constraintsStatesIn.length, subAction.constraintsStatesNotIn.length]);

  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);

  const changeConnectionConstraints = useCallback(
    (ev: SelectChangeEvent<ProcessConnection[]>) => {
      const value = ev.target.value;
      const values = typeof value === 'string' ? value.split(',').map(it => it as ProcessConnection) : value;
      updateEdge(id, draft => {
        draft.data = draft.data ?? {
          isEmailAction: false,
          subActions: [],
        };
        draft.data.subActions[index].constraintsConnectionsIn = values;
      });
    },
    [id, index, updateEdge],
  );

  const changeDirectionConstraints = useCallback(
    (ev: SelectChangeEvent<ProcessDirection[]>) => {
      const value = ev.target.value;
      const values = typeof value === 'string' ? value.split(',').map(it => it as ProcessDirection) : value;
      updateEdge(id, draft => {
        draft.data = draft.data ?? {
          isEmailAction: false,
          subActions: [],
        };
        draft.data.subActions[index].constraintsDirectionsIn = values;
      });
    },
    [id, index, updateEdge],
  );

  const changeOriginConstraints = useCallback(
    (ev: SelectChangeEvent<ProcessOrigin[]>) => {
      const value = ev.target.value;
      const values = typeof value === 'string' ? value.split(',').map(it => it as ProcessOrigin) : value;
      updateEdge(id, draft => {
        draft.data = draft.data ?? {
          isEmailAction: false,
          subActions: [],
        };
        draft.data.subActions[index].constraintsOriginsIn = values;
      });
    },
    [id, index, updateEdge],
  );

  return (
    <Stack direction="row" spacing={1}>
      <TextField size="small" variant="standard" placeholder="Variant name" value={subAction.label} onChange={inputChange} />
      <SubActionRowArea id={id} index={index} subAction={subAction} />
      <IconButton size="small" onClick={ev => setAnchorEl(ev.currentTarget)}>
        {hasConstraints ? <Lock color="error" /> : <LockOpen />}
      </IconButton>
      <Popover
        open={!!anchorEl}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        onDoubleClick={prevent}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}>
        <List dense style={{ width: '400px' }}>
          <ListItem dense>
            <InputLabel id="connections">Connections</InputLabel>
            <Select labelId="connections" value={subAction.constraintsConnectionsIn} size="small" variant="standard" fullWidth multiple onChange={changeConnectionConstraints}>
              <MenuItem value={ProcessConnection.AS2}>AS2</MenuItem>
              <MenuItem value={ProcessConnection.SFTP}>SFTP</MenuItem>
              <MenuItem value={ProcessConnection.HTTP}>HTTP</MenuItem>
              <MenuItem value={ProcessConnection.VAN}>VAN</MenuItem>
              <MenuItem value={ProcessConnection.WEBHOOK}>Web Hook</MenuItem>
            </Select>
          </ListItem>
          <ListItem dense>
            <InputLabel id="origins">Directions</InputLabel>
            <Select labelId="origins" value={subAction.constraintsDirectionsIn} size="small" variant="standard" fullWidth multiple onChange={changeDirectionConstraints}>
              <MenuItem value={ProcessDirection.INBOUND}>Inbound</MenuItem>
              <MenuItem value={ProcessDirection.OUTBOUND}>Outbound</MenuItem>
            </Select>
          </ListItem>
          <ListItem dense>
            <InputLabel id="connections">Origins</InputLabel>
            <Select labelId="connections" value={subAction.constraintsOriginsIn} size="small" variant="standard" fullWidth multiple onChange={changeOriginConstraints}>
              <MenuItem value={ProcessOrigin.INTERNAL}>Internal</MenuItem>
              <MenuItem value={ProcessOrigin.EXTERNAL}>External</MenuItem>
            </Select>
          </ListItem>
        </List>
      </Popover>
      <IconButton size="small" onClick={deleteSubAction}>
        <Close />
      </IconButton>
    </Stack>
  );
};

// ------------------------------------------------------------------------------------------------

const SubActionRowArea: React.FC<SubActionProps> = ({ id, index, subAction }) => {
  const { updateEdge } = useReactFlowHooks();
  const toggleReminder = useCallback(() => {
    updateEdge(id, draft => {
      draft.data = draft.data ?? {
        isEmailAction: false,
        subActions: [],
      };
      draft.data.subActions[index].hasReminder = !draft.data.subActions[index].hasReminder;
    });
  }, [updateEdge, id, index]);

  return (
    <>
      <TextField
        size="small"
        variant="standard"
        placeholder="Email template"
        value="email-template.html"
        disabled
        InputProps={{
          endAdornment: (
            <IconButton size="small">
              <AttachEmail />
            </IconButton>
          ),
        }}
      />
      {subAction.hasReminder && (
        <>
          <TextField
            size="small"
            variant="standard"
            placeholder="Reminder email template"
            value="reminder-template.html"
            disabled
            InputProps={{
              endAdornment: (
                <IconButton size="small">
                  <AttachEmail />
                </IconButton>
              ),
            }}
          />
        </>
      )}
      <IconButton size="small" color={subAction.hasReminder ? 'primary' : 'default'} onClick={toggleReminder}>
        <AccessAlarm />
      </IconButton>
    </>
  );
};

// ------------------------------------------------------------------------------------------------

export const CustomEdgeToolbarPlaceholder: React.FC = () => {
  const edges = useEdges<Action>();

  const [id = ''] = useRecoilValue(selectedEdgeIdsState);
  const edgeLabelCoords = useRecoilValue(selectedEdgeLabelCoordsState);
  const edge = useMemo(() => edges.find(it => it.id === id), [id, edges]);

  if (!edge || !edgeLabelCoords) return null;
  return <CustomEdgeToolbar edge={edge} edgeLabelCoords={edgeLabelCoords} />;
};
