import { XYPosition } from 'reactflow';
import { atom } from 'recoil';

export const selectedNodeIdsState = atom<string[]>({
  key: 'selectedNodeIds',
  default: [],
});

export const selectedEdgeIdsState = atom<string[]>({
  key: 'selectedEdgeIds',
  default: [],
});

export const selectedEdgeLabelCoordsState = atom<XYPosition | undefined>({
  key: 'selectedEdgeLabelCoords',
  default: undefined,
});
