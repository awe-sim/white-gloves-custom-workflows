import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './process-flow/App.tsx';
import { ReactFlowProvider } from 'reactflow';
import { RecoilRoot } from 'recoil';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <RecoilRoot>
      <ReactFlowProvider>
        <App />
      </ReactFlowProvider>
    </RecoilRoot>
  </React.StrictMode>,
);
